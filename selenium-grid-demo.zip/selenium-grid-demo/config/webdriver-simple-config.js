const { Builder } = require('selenium-webdriver');

async function createDriver() {
  return await new Builder()
    .usingServer('http://localhost:4444/wd/hub')
    .forBrowser('chrome')
    .build();
}

module.exports = createDriver;
