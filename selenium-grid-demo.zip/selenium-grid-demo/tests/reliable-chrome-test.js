const createDriver = require('../config/webdriver-simple-config');
const { By } = require('selenium-webdriver');

(async function loginTest() {
  const driver = await createDriver();

  try {
    await driver.get('https://www.saucedemo.com/');
    await driver.findElement(By.id('user-name')).sendKeys('standard_user');
    await driver.findElement(By.id('password')).sendKeys('secret_sauce');
    await driver.findElement(By.id('login-button')).click();

    await driver.sleep(3000);
    const currentUrl = await driver.getCurrentUrl();
    console.log('Login exitoso, URL actual:', currentUrl);
  } catch (error) {
    console.error('Error en la prueba:', error);
  } finally {
    await driver.quit();
  }
})();
